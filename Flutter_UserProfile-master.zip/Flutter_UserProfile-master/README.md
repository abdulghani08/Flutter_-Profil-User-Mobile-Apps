# Flutter User Profile App
 
This repository shows how I built a simple User Profile UI using Flutter. Please note that I was unable to get the Profile Image to update when a user selects a new photo.

#Installation
1) Please have Flutter environment setup. If you do not have flutter, please follow the instructions in this link: https://flutter.dev/docs/get-started/install
2) Download and/or clone this repository to your IDE of choice. I prefer Visual Studio Code.
3) Run the project using any desired Android, iOS, or macOs simulator (i.e. Pixel, Iphone, or macOS simulator)

# Here's How It Looks
<img width="564" alt="UserProfileImage" src="https://user-images.githubusercontent.com/57332846/139486860-6106b054-17e0-458b-ac0b-4af51ab579e2.png">


https://user-images.githubusercontent.com/57332846/139486864-11952daf-6ab7-46de-a2cb-2264c3a25173.mov




